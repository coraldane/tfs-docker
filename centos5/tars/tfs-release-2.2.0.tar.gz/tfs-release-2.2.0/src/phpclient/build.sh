#/bin/sh
/home/duanfei/local/bin/phpize --clean                                                                                             
/home/duanfei/local/bin/phpize
./configure --with-php-config=/home/duanfei/local/bin/php-config
