#/bin/bash
/home/duanfei/local/bin/php -q test.php "10.232.36.203:5100" "duanfei_php_test" "10.232.35.97" 
/home/duanfei/local/bin/php -q test_meta.php "10.232.36.203:5100" "duanfei_php_test" "10.232.35.97" 
